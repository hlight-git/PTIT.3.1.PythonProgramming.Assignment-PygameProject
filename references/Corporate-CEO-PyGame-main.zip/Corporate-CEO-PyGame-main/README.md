# Corporate-CEO-PyGame

This is my PyGame where I'm going to use real-life economic information to influence a PyGame game. Here's the link to my YouTube Playlist for this game. https://www.youtube.com/playlist?list=PLT8WeU5lHsiQm3IRC5Ej4wa8VPGyaOOwk

# 2 Jan 2021 Update
Click here to watch the second video in my Pygame playlist. https://youtu.be/wIKaxUXnEps In this video, we create a New Game/Load Game screen and when we click on the New Game it takes us to a start your own character. We can type in our names and click on the career path we want.

# 9 Jan 2021 Update
Click here to watch the third video in my Pygame playlist. In this video, we use the python library shelve which is part of the standard library to save and load game data. The game is lacking some user error handling right now, so we'll work on improving the logic in future updates.
